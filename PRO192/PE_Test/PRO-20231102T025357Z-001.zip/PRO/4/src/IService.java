public interface IService {
    String formatSize();
    String formatName();
}


